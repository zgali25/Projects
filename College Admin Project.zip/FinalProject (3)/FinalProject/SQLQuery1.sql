USE TinyDB;

SELECT * FROM Instructors;
SELECT * FROM Courses;
SELECT * FROM Students;
SELECT * FROM StudentCourses;
