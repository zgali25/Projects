﻿USE master;

-- Drop the database "TinyDB" if it exists.
IF DB_ID(N'TinyDB') IS NOT NULL
BEGIN
    ALTER DATABASE TinyDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE TinyDB;
END

-- Create a new database named "TinyDB".
CREATE DATABASE TinyDB;
GO

-- Use the "TinyDB" database for subsequent operations.
USE TinyDB;
GO

-- Create the "Instructors" table to store information about instructors.
CREATE TABLE Instructors (
    InstructorId INT PRIMARY KEY,
    InstructorName NVARCHAR(50)
);
GO

-- Create the "Students" table to store information about students.
CREATE TABLE Students (
    StudentId INT PRIMARY KEY,
    StudentName NVARCHAR(255),
    CoursesRegistered NVARCHAR(MAX),
    Grade NVARCHAR(255),
    GradeDetails NVARCHAR(MAX)
);
GO

-- Create the "Courses" table to store information about courses.
-- The "InstructorId" column is a foreign key referencing the "Instructors" table.
CREATE TABLE Courses (
    CourseId INT PRIMARY KEY,
    CourseTitle NVARCHAR(100),
    InstructorId INT,
    AvailableSeats INT,
    IsActive BIT,
    InstructorName NVARCHAR(50),
    FOREIGN KEY (InstructorId) REFERENCES Instructors(InstructorId),
    CreditHours INT
);
GO

-- Insert sample data into the "Instructors" table.
INSERT INTO Instructors (InstructorId, InstructorName)
VALUES (1, 'Salamah Peake'), (2, 'Ian Rhoades'), (3, 'Zach Galindo'), (4, 'Erin York');

-- Insert sample data into the "Students" table.
INSERT INTO Students (StudentId, StudentName, CoursesRegistered)
VALUES
    (1, 'Cole Shelter',1),
    (2, 'Jarod Smith',2),
    (3, 'Christina Fulton',3), 
    (4, 'Johnny Gerard',4), 
    (5, 'Darryl Philbin',5),
    (6, 'Carlos Sanchez',6),
    (7, 'John Daily',7),
    (8, 'Sarah Jones',8);

-- Insert sample data into the "Courses" table.
INSERT INTO Courses (CourseId, CourseTitle, InstructorId, AvailableSeats, IsActive, InstructorName)
VALUES 
    (1, 'Art History', 1, 9, 1, 'Salamah Peake'),
    (2, 'Programming 101', 2, 8, 1, 'Ian Rhoades'),
    (3, 'Advanced Mathematics', 2, 6, 1, 'Ian Rhoades'),
    (4, 'Creative Writing', 3, 3, 1, 'Zach Galindo'),
    (5, 'Astronomy', 3, 4, 1, 'Zach Galindo'),
    (6, 'Modern Philosophy', 3, 7, 1, 'Zach Galindo'),
    (7, 'Spanish 2', 1, 14, 1, 'Salamah Peake'),
    (8, 'Bird Watching', 1, 14, 1, 'Salamah Peake'),
    (9, 'Cooking', 4, 15, 1, 'Erin York'),
    (10, 'Football', 4, 0, 0, 'Erin York');

-- Create the "StudentCourses" table to store the relationship between students and courses.
CREATE TABLE StudentCourses (
    StudentId INT NOT NULL,
    CourseId INT NOT NULL,
    CONSTRAINT PK_StudentCourses PRIMARY KEY (StudentId, CourseId),
    CONSTRAINT FK_StudentCourses_Students FOREIGN KEY (StudentId) REFERENCES Students (StudentId) ON DELETE CASCADE,
    CONSTRAINT FK_StudentCourses_Courses FOREIGN KEY (CourseId) REFERENCES Courses (CourseId) ON DELETE CASCADE,
    Grade NVARCHAR(255)
);

-- Insert data into the StudentCourses table.
INSERT INTO StudentCourses (StudentId, CourseId, Grade)
VALUES
    (1, 1, 'A'),
    (2, 2, 'B'),
    (3, 3, 'C'),
    (4, 4, NULL),
    (5, 5, NULL),
    (6, 6, NULL),
    (7, 7, NULL),
    (8, 8, NULL);

    USE TinyDB;

SELECT * FROM Instructors;
SELECT * FROM Courses;
SELECT * FROM Students;
SELECT * FROM StudentCourses;

